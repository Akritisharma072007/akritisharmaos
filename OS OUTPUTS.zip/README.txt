AKRITI - OPERATING SYSTEM LAB OUTPUT SCREENSHOTS
These are VirtualBox/Ubuntu-style illustrative sample output captures for the 11 experiments.
They are formatted with the terminal username @akriti as requested.
PID values, timestamps, memory addresses, and /proc map lines are examples and will vary on a real run.
Run the supplied source files in Ubuntu/VirtualBox to capture your machine's exact live output.
